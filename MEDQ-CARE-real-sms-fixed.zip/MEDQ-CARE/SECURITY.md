# MEDQ-CARE security notes

Implemented in this version:
- Helmet security headers.
- CORS restricted to `FRONTEND_ORIGIN`.
- Rate limiting on OTP send endpoints.
- Real OTP verification through Twilio Verify; OTP codes are not stored in the application.
- JWT authentication for patient and hospital-staff API routes.
- Role checks for patient, doctor, reception, and admin routes.
- Passwords supplied by patients are bcrypt-hashed before being stored in the current in-memory patient store.
- Twilio credentials stay in backend environment variables and are never exposed to React.

Before a real healthcare production deployment, add a persistent database, HTTPS, secure cookie/token strategy, audit logging, backups, access reviews, data encryption, and compliance controls appropriate to the jurisdiction.
