const validateAppointment = (data) => {
    const requiredFields = [
        "patientId",
        "hospitalId",
        "doctorId",
        "department",
        "date",
        "time"
    ];

    for (const field of requiredFields) {
        if (
            data[field] === undefined ||
            data[field] === null ||
            data[field] === ""
        ) {
            return {
                valid: false,
                message: `${field} is required`
            };
        }
    }

    return {
        valid: true
    };
};

module.exports = {
    validateAppointment
};