const express = require("express");
const {
  createAppointment, getAppointments, getAppointmentsByPatient,
  getAppointmentById, cancelAppointment, cancelAppointmentByDelete,
  getAvailableSlots,
} = require("../controllers/appointmentController");

const router = express.Router();

router.post("/", createAppointment);
router.get("/patient/:patientId", getAppointmentsByPatient);
router.get("/slots", getAvailableSlots);
router.get("/", getAppointments);
router.get("/:id", getAppointmentById);
router.put("/:id/cancel", cancelAppointment);
router.delete("/:id", cancelAppointmentByDelete);

module.exports = router;
