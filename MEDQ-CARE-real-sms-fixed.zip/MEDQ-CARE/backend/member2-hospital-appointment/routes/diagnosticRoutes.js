const express = require("express");
const {
  getDiagnosticServices, getDiagnosticServiceById,
  getLabServices, getImagingServices, bookDiagnostic, getReports
} = require("../controllers/diagnosticController");

const router = express.Router();

router.get("/lab", getLabServices);
router.post("/lab", bookDiagnostic);
router.get("/imaging", getImagingServices);
router.post("/imaging", bookDiagnostic);
router.get("/reports/:patientId", getReports);
router.get("/", getDiagnosticServices);
router.get("/:id", getDiagnosticServiceById);

module.exports = router;
