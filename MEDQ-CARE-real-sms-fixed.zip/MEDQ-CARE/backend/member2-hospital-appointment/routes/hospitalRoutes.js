const express = require("express");
const {
  getHospitals, getHospitalById, getDepartments,
  getDoctors, getHospitalServices, getDoctorById,
} = require("../controllers/hospitalController");

const router = express.Router();

router.get("/", getHospitals);
router.get("/:id/departments", getDepartments);
router.get("/:id/services", getHospitalServices);
router.get("/:id", getHospitalById);

module.exports = router;

const departmentRouter = express.Router();
departmentRouter.get("/departments/:departmentId/doctors", getDoctors);
departmentRouter.get("/doctors/:doctorId", getDoctorById);
module.exports.departmentRouter = departmentRouter;
