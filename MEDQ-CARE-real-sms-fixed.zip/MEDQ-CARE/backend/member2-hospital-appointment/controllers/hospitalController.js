const hospitals = [
  { id: 1, name: "Apollo Hospitals", location: "Chennai", departments: ["Cardiology", "Neurology", "General Medicine"], phone: "044-28293333" },
  { id: 2, name: "MIOT International", location: "Chennai", departments: ["Orthopedics", "Cardiology", "Radiology"], phone: "044-42002288" },
  { id: 3, name: "Kauvery Hospital", location: "Chennai", departments: ["Cardiology", "Pediatrics", "Neurology"], phone: "044-40006000" },
];

const doctors = [
  { id: 1, name: "Dr. Arun Kumar", departmentId: 1, department: "Cardiology", specialization: "Cardiologist" },
  { id: 2, name: "Dr. Priya Sharma", departmentId: 2, department: "Dermatology", specialization: "Dermatologist" },
  { id: 3, name: "Dr. Ravi", departmentId: 3, department: "General Medicine", specialization: "Physician" },
];

const getHospitals = (req, res) =>
  res.json({ success: true, count: hospitals.length, data: hospitals });

const getHospitalById = (req, res) => {
  const hospital = hospitals.find(h => h.id === Number(req.params.id));
  if (!hospital) return res.status(404).json({ success: false, message: "Hospital not found" });
  res.json({ success: true, data: hospital });
};

const getDepartments = (req, res) => {
  const hospital = hospitals.find(h => h.id === Number(req.params.id));
  if (!hospital) return res.status(404).json({ success: false, message: "Hospital not found" });
  res.json({ success: true, data: hospital.departments.map((name, i) => ({ id: i + 1, name })) });
};

const getDoctors = (req, res) => {
  const departmentId = Number(req.params.departmentId);
  const result = doctors.filter(d => d.departmentId === departmentId);
  res.json({ success: true, data: result });
};

const getHospitalServices = (req, res) => {
  const hospital = hospitals.find(h => h.id === Number(req.params.id));
  if (!hospital) return res.status(404).json({ success: false, message: "Hospital not found" });
  res.json({ success: true, data: ["Consultation", "Laboratory", "Imaging", "Pharmacy"] });
};

const getDoctorById = (req, res) => {
  const doctor = doctors.find(d => d.id === Number(req.params.doctorId));
  if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });
  res.json({ success: true, data: doctor });
};

module.exports = {
  getHospitals, getHospitalById, getDepartments, getDoctors,
  getHospitalServices, getDoctorById,
};
