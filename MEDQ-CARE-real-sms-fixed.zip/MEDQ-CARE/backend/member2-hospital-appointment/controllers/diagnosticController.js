const diagnosticServices = [
    {
        id: 1,
        name: "Blood Test",
        category: "Laboratory",
        price: 500
    },
    {
        id: 2,
        name: "CBC Test",
        category: "Laboratory",
        price: 350
    },
    {
        id: 3,
        name: "X-Ray",
        category: "Imaging",
        price: 800
    },
    {
        id: 4,
        name: "Ultrasound",
        category: "Imaging",
        price: 1200
    },
    {
        id: 5,
        name: "CT Scan",
        category: "Imaging",
        price: 3000
    }
];

const getDiagnosticServices = (req, res) => {
    res.status(200).json({
        success: true,
        count: diagnosticServices.length,
        data: diagnosticServices
    });
};

const getDiagnosticServiceById = (req, res) => {
    const service = diagnosticServices.find(
        s => s.id === Number(req.params.id)
    );

    if (!service) {
        return res.status(404).json({
            success: false,
            message: "Diagnostic service not found"
        });
    }

    res.status(200).json({
        success: true,
        data: service
    });
};

const getLabServices = (req, res) => {
    const data = diagnosticServices.filter(s => s.category === "Laboratory");
    res.json({ success: true, count: data.length, data });
};

const getImagingServices = (req, res) => {
    const data = diagnosticServices.filter(s => s.category === "Imaging");
    res.json({ success: true, count: data.length, data });
};

const bookDiagnostic = (req, res) => {
    res.status(201).json({
        success: true,
        message: "Diagnostic booking created successfully",
        data: { id: Date.now(), ...req.body, status: "BOOKED" }
    });
};

const getReports = (req, res) => {
    res.json({ success: true, data: [] });
};

module.exports = {
    getDiagnosticServices,
    getDiagnosticServiceById,
    getLabServices,
    getImagingServices,
    bookDiagnostic,
    getReports
};