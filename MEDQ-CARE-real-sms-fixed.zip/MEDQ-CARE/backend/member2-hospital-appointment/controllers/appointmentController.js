const {
    validateAppointment
} = require("../services/appointmentValidation");

let appointments = [];
let nextAppointmentId = 1;

const createAppointment = (req, res) => {
    const validation = validateAppointment(req.body);

    if (!validation.valid) {
        return res.status(400).json({
            success: false,
            message: validation.message
        });
    }

    const appointment = {
        id: nextAppointmentId++,
        patientId: req.body.patientId,
        hospitalId: req.body.hospitalId,
        doctorId: req.body.doctorId,
        department: req.body.department,
        date: req.body.date,
        time: req.body.time,
        type: req.body.type || "Consultation",
        status: "BOOKED",
        createdAt: new Date().toISOString()
    };

    appointments.push(appointment);

    res.status(201).json({
        success: true,
        message: "Appointment booked successfully",
        data: appointment
    });
};

const getAppointments = (req, res) => {
    const { patientId } = req.query;

    let result = appointments;

    if (patientId) {
        result = appointments.filter(
            appointment =>
                String(appointment.patientId) === String(patientId)
        );
    }

    res.status(200).json({
        success: true,
        count: result.length,
        data: result
    });
};

const getAppointmentById = (req, res) => {
    const appointment = appointments.find(
        a => a.id === Number(req.params.id)
    );

    if (!appointment) {
        return res.status(404).json({
            success: false,
            message: "Appointment not found"
        });
    }

    res.status(200).json({
        success: true,
        data: appointment
    });
};

const cancelAppointment = (req, res) => {
    const appointment = appointments.find(
        a => a.id === Number(req.params.id)
    );

    if (!appointment) {
        return res.status(404).json({
            success: false,
            message: "Appointment not found"
        });
    }

    appointment.status = "CANCELLED";

    res.status(200).json({
        success: true,
        message: "Appointment cancelled successfully",
        data: appointment
    });
};

const getAppointmentsByPatient = (req, res) => {
    const { patientId } = req.params;
    req.query.patientId = patientId;
    return getAppointments(req, res);
};

const cancelAppointmentByDelete = (req, res) => cancelAppointment(req, res);

const getAvailableSlots = (req, res) => {
    res.json({
        success: true,
        data: [
            { time: "09:00 AM", available: true },
            { time: "10:00 AM", available: true },
            { time: "11:00 AM", available: true },
            { time: "02:00 PM", available: true }
        ]
    });
};

module.exports = {
    createAppointment,
    getAppointments,
    getAppointmentsByPatient,
    getAppointmentById,
    cancelAppointment,
    cancelAppointmentByDelete,
    getAvailableSlots
};