const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const otpService = require("../services/otpService");

const users = new Map();
let nextUserId = 1;

const issueToken = (user) => jwt.sign(
  { id: user.id, phone: user.phone, role: user.role },
  process.env.JWT_SECRET,
  { expiresIn: process.env.JWT_EXPIRES_IN || "8h" }
);

const publicUser = (user) => ({
  id: user.id,
  name: user.name,
  email: user.email,
  phone: user.phone,
  role: user.role,
  verified: user.verified,
});

const register = async (req, res) => {
  try {
    const { name, email, phone, mobile, password } = req.body;
    const normalizedPhone = otpService.normalizePhone(phone || mobile);

    if (!name || !normalizedPhone) {
      return res.status(400).json({ success: false, message: "Name and mobile/phone are required" });
    }

    if (users.has(normalizedPhone)) {
      return res.status(409).json({ success: false, message: "A patient with this mobile number already exists" });
    }

    const passwordHash = password ? await bcrypt.hash(password, 12) : null;
    const user = {
      id: `P${String(nextUserId++).padStart(4, "0")}`,
      name: name.trim(),
      email: email?.trim() || null,
      phone: normalizedPhone,
      passwordHash,
      role: "patient",
      verified: false,
    };

    users.set(normalizedPhone, user);
    await otpService.sendOTP(normalizedPhone);

    res.status(201).json({
      success: true,
      message: "Registration successful. A verification code has been sent by SMS.",
      user: publicUser(user),
      otpRequired: true,
    });
  } catch (error) {
    console.error("Patient registration error:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

const login = async (req, res) => {
  try {
    const normalizedPhone = otpService.normalizePhone(req.body.phone || req.body.mobile);
    let user = users.get(normalizedPhone);

    if (!user) {
      user = {
        id: `P${String(nextUserId++).padStart(4, "0")}`,
        name: "Patient",
        email: null,
        phone: normalizedPhone,
        passwordHash: null,
        role: "patient",
        verified: false,
      };
      users.set(normalizedPhone, user);
    }

    await otpService.sendOTP(normalizedPhone);

    res.json({
      success: true,
      message: "Verification code sent by SMS",
      otpRequired: true,
      phone: normalizedPhone,
    });
  } catch (error) {
    console.error("Patient OTP send error:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

const verifyOTP = async (req, res) => {
  try {
    const normalizedPhone = otpService.normalizePhone(req.body.phone || req.body.mobile);
    const result = await otpService.verifyOTP(normalizedPhone, req.body.otp);

    if (!result.success) return res.status(400).json(result);

    const user = users.get(normalizedPhone);
    if (!user) return res.status(404).json({ success: false, message: "Patient account not found" });

    user.verified = true;

    res.json({
      success: true,
      message: "OTP verified successfully",
      token: issueToken(user),
      user: publicUser(user),
    });
  } catch (error) {
    console.error("OTP verification error:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

const resendOTP = async (req, res) => {
  try {
    const normalizedPhone = otpService.normalizePhone(req.body.phone || req.body.mobile);
    if (!users.has(normalizedPhone)) {
      return res.status(404).json({ success: false, message: "Patient account not found" });
    }
    await otpService.sendOTP(normalizedPhone);
    res.json({ success: true, message: "A new verification code has been sent by SMS" });
  } catch (error) {
    console.error("OTP resend error:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { register, verifyOTP, login, resendOTP };
