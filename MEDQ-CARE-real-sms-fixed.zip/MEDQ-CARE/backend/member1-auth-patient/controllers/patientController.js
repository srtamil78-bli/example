const mockAbhaService = require("../services/mockAbhaService");

const patients = [
  {
    id: 1,
    name: "Patient",
    email: "patient@example.com",
    phone: "+91 98765 43210",
    dateOfBirth: "01 Jan 2000",
    gender: "Not Specified",
    bloodGroup: "O+",
    address: "Chennai, Tamil Nadu",
    abhaNumber: "12-3456-7890-1234",
  },
];

const getProfile = async (req, res) => {
  try {
    res.json({ success: true, data: patients[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateProfile = async (req, res) => {
  try {
    const patient = patients[0];
    const { name, phone, dateOfBirth, gender, bloodGroup, address } = req.body;

    if (name) patient.name = name;
    if (phone) patient.phone = phone;
    if (dateOfBirth) patient.dateOfBirth = dateOfBirth;
    if (gender) patient.gender = gender;
    if (bloodGroup) patient.bloodGroup = bloodGroup;
    if (address) patient.address = address;

    res.json({
      success: true,
      message: "Profile updated successfully",
      data: patient,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createAbha = async (req, res) => {
  try {
    const result = await mockAbhaService.createMockAbha(req.body);

    if (result.success) {
      patients[0].abhaNumber = result.data.abhaNumber;
    }

    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAbha = async (req, res) => {
  try {
    const result = await mockAbhaService.getMockAbha(req.params.abhaNumber);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getProfile, updateProfile, createAbha, getAbha };
