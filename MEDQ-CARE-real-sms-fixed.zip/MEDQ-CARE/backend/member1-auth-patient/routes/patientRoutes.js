const express = require("express");
const { authenticateToken, authorizeRoles } = require("../../middleware/auth");

const {
getProfile,
updateProfile,
createAbha,
getAbha,
} = require("../controllers/patientController");

const router = express.Router();
router.use(authenticateToken, authorizeRoles("patient"));

router.get("/profile", getProfile);

router.put("/profile", updateProfile);

router.post("/abha", createAbha);

router.get("/abha/:abhaNumber", getAbha);

module.exports = router;
