const twilio = require("twilio");

const required = [
  "TWILIO_ACCOUNT_SID",
  "TWILIO_AUTH_TOKEN",
  "TWILIO_VERIFY_SERVICE_SID",
];

const getClient = () => {
  const missing = required.filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Real SMS OTP is not configured. Missing: ${missing.join(", ")}`);
  }
  return twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
};

const normalizePhone = (value) => {
  const raw = String(value || "").trim().replace(/[\s()-]/g, "");
  if (/^\d{10}$/.test(raw)) return `+91${raw}`;
  if (/^91\d{10}$/.test(raw)) return `+${raw}`;
  if (/^\+91\d{10}$/.test(raw)) return raw;
  throw new Error("Please enter a valid Indian mobile number in E.164 format (+91XXXXXXXXXX)");
};

const sendOTP = async (phone) => {
  const normalizedPhone = normalizePhone(phone);
  const client = getClient();

  const verification = await client.verify.v2
    .services(process.env.TWILIO_VERIFY_SERVICE_SID)
    .verifications.create({
      channel: "sms",
      to: normalizedPhone,
    });

  console.log(`[OTP] SMS verification started for ${normalizedPhone}: ${verification.status}`);
  return { success: true, status: verification.status, phone: normalizedPhone };
};

const verifyOTP = async (phone, otp) => {
  const normalizedPhone = normalizePhone(phone);
  const code = String(otp || "").trim();

  if (!/^\d{6}$/.test(code)) {
    return { success: false, message: "OTP must be a 6-digit code" };
  }

  const client = getClient();
  const check = await client.verify.v2
    .services(process.env.TWILIO_VERIFY_SERVICE_SID)
    .verificationChecks.create({
      to: normalizedPhone,
      code,
    });

  return {
    success: check.status === "approved",
    status: check.status,
    message: check.status === "approved" ? "OTP verified successfully" : "Invalid or expired OTP",
    phone: normalizedPhone,
  };
};

module.exports = { sendOTP, verifyOTP, normalizePhone };
