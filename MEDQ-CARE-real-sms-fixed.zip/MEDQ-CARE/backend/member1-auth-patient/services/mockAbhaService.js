const generateAbhaNumber = () => {
const part1 = Math.floor(10 + Math.random() * 90);
const part2 = Math.floor(1000 + Math.random() * 9000);
const part3 = Math.floor(1000 + Math.random() * 9000);
const part4 = Math.floor(1000 + Math.random() * 9000);

return `${part1}-${part2}-${part3}-${part4}`;
};

const createMockAbha = async (patientData) => {
return {
success: true,
message: "Mock ABHA account created successfully",
data: {
abhaNumber: generateAbhaNumber(),
name: patientData.name,
dateOfBirth: patientData.dateOfBirth || null,
gender: patientData.gender || null,
linked: true,
},
};
};

const getMockAbha = async (abhaNumber) => {
return {
success: true,
data: {
abhaNumber,
name: "Patient",
dateOfBirth: "01 Jan 2000",
gender: "Not Specified",
linked: true,
},
};
};

module.exports = {
createMockAbha,
getMockAbha,
};
