// services/auditService.js

const auditLogs = [];

// Record an audit event
const createAuditLog = ({
  userId,
  role,
  action,
  details = {},
}) => {
  const log = {
    id: `AUDIT-${Date.now()}`,
    userId: userId || null,
    role: role || null,
    action,
    details,
    timestamp: new Date().toISOString(),
  };

  auditLogs.push(log);

  console.log("AUDIT LOG:", log);

  return log;
};


// Get all audit logs
const getAuditLogs = () => {
  return auditLogs;
};


// Get logs for a particular user
const getUserAuditLogs = (userId) => {
  return auditLogs.filter(
    (log) => log.userId === userId
  );
};


module.exports = {
  createAuditLog,
  getAuditLogs,
  getUserAuditLogs,
};