// services/consultationService.js

const consultations = [];


// ========================================
// START CONSULTATION
// ========================================

const startConsultation = ({
  appointmentId,
  doctorId,
  patientId,
}) => {
  const consultation = {
    id: `CONS-${Date.now()}`,
    appointmentId,
    doctorId,
    patientId,
    startTime: new Date().toISOString(),
    endTime: null,
    diagnosis: "",
    prescription: "",
    notes: "",
    status: "In Consultation",
  };

  consultations.push(consultation);

  return consultation;
};


// ========================================
// COMPLETE CONSULTATION
// ========================================

const completeConsultation = ({
  appointmentId,
  diagnosis = "",
  prescription = "",
  notes = "",
}) => {
  const consultation = consultations.find(
    (item) =>
      item.appointmentId === appointmentId &&
      item.status === "In Consultation"
  );

  if (!consultation) {
    return null;
  }

  consultation.endTime =
    new Date().toISOString();

  consultation.diagnosis = diagnosis;
  consultation.prescription = prescription;
  consultation.notes = notes;
  consultation.status = "Completed";

  return consultation;
};


// ========================================
// GET CONSULTATION
// ========================================

const getConsultation = (appointmentId) => {
  return consultations.find(
    (item) =>
      item.appointmentId === appointmentId
  );
};


// ========================================
// GET ALL CONSULTATIONS
// ========================================

const getAllConsultations = () => {
  return consultations;
};


module.exports = {
  startConsultation,
  completeConsultation,
  getConsultation,
  getAllConsultations,
};