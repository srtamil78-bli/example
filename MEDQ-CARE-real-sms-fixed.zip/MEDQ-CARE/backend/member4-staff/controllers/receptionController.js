const jwt = require("jsonwebtoken");
// controllers/receptionController.js

// ===============================
// RECEPTION LOGIN
// ===============================

const receptionLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: "Username and password are required",
      });
    }

    const expectedUsername = process.env.RECEPTION_USERNAME;
    const expectedPassword = process.env.RECEPTION_PASSWORD;

    if (username === expectedUsername && password === expectedPassword) {
      const token = jwt.sign(
        { id: "R001", username, role: "reception" },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || "8h" }
      );
      return res.status(200).json({
        success: true,
        message: "Reception login successful",
        token,
        user: { id: "R001", username, role: "reception" },
      });
    }

    return res.status(401).json({
      success: false,
      message: "Invalid reception credentials",
    });
  } catch (error) {
    console.error(
      "Reception Login Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};


// ===============================
// GET APPOINTMENTS
// ===============================

const getAppointments = async (req, res) => {
  try {
    const appointments = [
      {
        appointmentId: "APT001",
        patientId: "P001",
        patientName: "Patient One",
        doctorName: "Dr. Arun",
        department: "Cardiology",
        time: "10:00 AM",
        status: "Confirmed",
      },
      {
        appointmentId: "APT002",
        patientId: "P002",
        patientName: "Patient Two",
        doctorName: "Dr. Ravi",
        department: "General Medicine",
        time: "10:30 AM",
        status: "Waiting",
      },
    ];

    return res.status(200).json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error(
      "Get Appointments Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch appointments",
    });
  }
};


// ===============================
// UPDATE APPOINTMENT
// ===============================

const updateAppointment = async (req, res) => {
  try {
    const { appointmentId } = req.params;

    const {
      doctorId,
      date,
      time,
      status,
    } = req.body;

    return res.status(200).json({
      success: true,
      message: "Appointment updated successfully",
      appointment: {
        appointmentId,
        doctorId,
        date,
        time,
        status,
      },
    });
  } catch (error) {
    console.error(
      "Update Appointment Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to update appointment",
    });
  }
};


// ===============================
// GET PATIENTS
// ===============================

const getPatients = async (req, res) => {
  try {
    const patients = [
      {
        patientId: "P001",
        name: "Patient One",
        age: 35,
        gender: "Male",
        phone: "9876543210",
      },
      {
        patientId: "P002",
        name: "Patient Two",
        age: 42,
        gender: "Female",
        phone: "9876543211",
      },
    ];

    return res.status(200).json({
      success: true,
      patients,
    });
  } catch (error) {
    console.error(
      "Get Patients Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch patients",
    });
  }
};


// ===============================
// SEARCH PATIENT
// ===============================

const searchPatient = async (req, res) => {
  try {
    const { query } = req.query;

    if (!query) {
      return res.status(400).json({
        success: false,
        message: "Search query is required",
      });
    }

    const patients = [
      {
        patientId: "P001",
        name: "Patient One",
        phone: "9876543210",
      },
      {
        patientId: "P002",
        name: "Patient Two",
        phone: "9876543211",
      },
    ];

    const result = patients.filter(
      (patient) =>
        patient.name
          .toLowerCase()
          .includes(query.toLowerCase()) ||
        patient.patientId
          .toLowerCase()
          .includes(query.toLowerCase()) ||
        patient.phone.includes(query)
    );

    return res.status(200).json({
      success: true,
      patients: result,
    });
  } catch (error) {
    console.error(
      "Search Patient Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to search patient",
    });
  }
};


// ===============================
// WALK-IN REGISTRATION
// ===============================

const registerWalkIn = async (req, res) => {
  try {
    const {
      name,
      age,
      gender,
      phone,
      department,
      doctor,
      reason,
    } = req.body;

    if (!name || !age || !phone) {
      return res.status(400).json({
        success: false,
        message:
          "Name, age and phone are required",
      });
    }

    return res.status(201).json({
      success: true,
      message:
        "Walk-in patient registered successfully",
      patient: {
        patientId: `P${Date.now()}`,
        name,
        age,
        gender,
        phone,
        department,
        doctor,
        reason,
      },
    });
  } catch (error) {
    console.error(
      "Walk-in Registration Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Walk-in registration failed",
    });
  }
};


// ===============================
// CHECK-IN PATIENT
// ===============================

const checkInPatient = async (req, res) => {
  try {
    const { appointmentId } = req.params;

    return res.status(200).json({
      success: true,
      message: "Patient checked in successfully",
      appointmentId,
      status: "Checked-In",
    });
  } catch (error) {
    console.error(
      "Patient Check-in Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Patient check-in failed",
    });
  }
};


module.exports = {
  receptionLogin,
  getAppointments,
  updateAppointment,
  getPatients,
  searchPatient,
  registerWalkIn,
  checkInPatient,
};