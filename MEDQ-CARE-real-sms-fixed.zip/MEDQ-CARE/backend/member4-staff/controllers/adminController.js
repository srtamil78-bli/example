const jwt = require("jsonwebtoken");
// controllers/adminController.js

// ===============================
// ADMIN LOGIN
// ===============================

const adminLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: "Username and password are required",
      });
    }

    const expectedUsername = process.env.ADMIN_USERNAME;
    const expectedPassword = process.env.ADMIN_PASSWORD;

    if (username === expectedUsername && password === expectedPassword) {
      const token = jwt.sign(
        { id: "A001", username, role: "admin" },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || "8h" }
      );
      return res.status(200).json({
        success: true,
        message: "Admin login successful",
        token,
        user: { id: "A001", username, role: "admin" },
      });
    }

    return res.status(401).json({
      success: false,
      message: "Invalid admin credentials",
    });
  } catch (error) {
    console.error("Admin Login Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};


// ===============================
// GET HOSPITALS
// ===============================

const getHospitals = async (req, res) => {
  try {
    const hospitals = [
      {
        id: "H001",
        name: "MEDQ CARE Hospital",
        location: "Chennai",
        status: "Active",
      },
    ];

    return res.status(200).json({
      success: true,
      hospitals,
    });
  } catch (error) {
    console.error("Get Hospitals Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch hospitals",
    });
  }
};


// ===============================
// GET DEPARTMENTS
// ===============================

const getDepartments = async (req, res) => {
  try {
    const departments = [
      {
        id: "D001",
        name: "Cardiology",
        status: "Active",
      },
      {
        id: "D002",
        name: "General Medicine",
        status: "Active",
      },
      {
        id: "D003",
        name: "Orthopedics",
        status: "Active",
      },
      {
        id: "D004",
        name: "Pediatrics",
        status: "Active",
      },
    ];

    return res.status(200).json({
      success: true,
      departments,
    });
  } catch (error) {
    console.error("Get Departments Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch departments",
    });
  }
};


// ===============================
// CREATE DEPARTMENT
// ===============================

const createDepartment = async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({
        success: false,
        message: "Department name is required",
      });
    }

    return res.status(201).json({
      success: true,
      message: "Department created successfully",
      department: {
        id: `D${Date.now()}`,
        name,
        status: "Active",
      },
    });
  } catch (error) {
    console.error("Create Department Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create department",
    });
  }
};


// ===============================
// UPDATE DEPARTMENT
// ===============================

const updateDepartment = async (req, res) => {
  try {
    const { departmentId } = req.params;
    const { name, status } = req.body;

    return res.status(200).json({
      success: true,
      message: "Department updated successfully",
      department: {
        id: departmentId,
        name,
        status: status || "Active",
      },
    });
  } catch (error) {
    console.error("Update Department Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update department",
    });
  }
};


// ===============================
// DELETE DEPARTMENT
// ===============================

const deleteDepartment = async (req, res) => {
  try {
    const { departmentId } = req.params;

    return res.status(200).json({
      success: true,
      message: "Department deleted successfully",
      departmentId,
    });
  } catch (error) {
    console.error("Delete Department Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete department",
    });
  }
};


module.exports = {
  adminLogin,
  getHospitals,
  getDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment,
};