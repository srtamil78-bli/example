const jwt = require("jsonwebtoken");
// controllers/doctorController.js

// ===============================
// DOCTOR LOGIN
// ===============================

const doctorLogin = async (req, res) => {
  try {
    const { doctorId, password } = req.body;

    if (!doctorId || !password) {
      return res.status(400).json({
        success: false,
        message: "Doctor ID and password are required",
      });
    }

    const expectedDoctorId = process.env.DOCTOR_ID;
    const expectedPassword = process.env.DOCTOR_PASSWORD;

    if (doctorId === expectedDoctorId && password === expectedPassword) {
      const token = jwt.sign(
        { id: doctorId, doctorId, role: "doctor" },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || "8h" }
      );
      return res.status(200).json({
        success: true,
        message: "Doctor login successful",
        token,
        user: { id: doctorId, doctorId, name: "Dr. Arun", role: "doctor" },
      });
    }

    return res.status(401).json({
      success: false,
      message: "Invalid doctor credentials",
    });
  } catch (error) {
    console.error("Doctor Login Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};


// ===============================
// DOCTOR PROFILE
// ===============================

const getDoctorProfile = async (req, res) => {
  try {
    const { doctorId } = req.params;

    return res.status(200).json({
      success: true,
      doctor: {
        id: doctorId,
        name: "Dr. Arun",
        department: "Cardiology",
        specialization: "Cardiologist",
        experience: "10 years",
        status: "Available",
      },
    });
  } catch (error) {
    console.error("Doctor Profile Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch doctor profile",
    });
  }
};


// ===============================
// TODAY'S PATIENTS
// ===============================

const getTodayPatients = async (req, res) => {
  try {
    const { doctorId } = req.params;

    const patients = [
      {
        appointmentId: "APT001",
        patientId: "P001",
        patientName: "Patient One",
        tokenNumber: 1,
        status: "Waiting",
      },
      {
        appointmentId: "APT002",
        patientId: "P002",
        patientName: "Patient Two",
        tokenNumber: 2,
        status: "Waiting",
      },
    ];

    return res.status(200).json({
      success: true,
      doctorId,
      patients,
    });
  } catch (error) {
    console.error("Today's Patients Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch today's patients",
    });
  }
};


// ===============================
// DOCTOR QUEUE
// ===============================

const getDoctorQueue = async (req, res) => {
  try {
    const { doctorId } = req.params;

    const queue = [
      {
        tokenNumber: 1,
        patientName: "Patient One",
        position: 1,
        status: "Waiting",
      },
      {
        tokenNumber: 2,
        patientName: "Patient Two",
        position: 2,
        status: "Waiting",
      },
    ];

    return res.status(200).json({
      success: true,
      doctorId,
      queue,
    });
  } catch (error) {
    console.error("Doctor Queue Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch doctor queue",
    });
  }
};


// ===============================
// START CONSULTATION
// ===============================

const startConsultation = async (req, res) => {
  try {
    const { appointmentId } = req.body;

    if (!appointmentId) {
      return res.status(400).json({
        success: false,
        message: "Appointment ID is required",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Consultation started",
      appointmentId,
      status: "In Consultation",
    });
  } catch (error) {
    console.error(
      "Start Consultation Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to start consultation",
    });
  }
};


// ===============================
// COMPLETE CONSULTATION
// ===============================

const completeConsultation = async (req, res) => {
  try {
    const {
      appointmentId,
      diagnosis,
      prescription,
      notes,
    } = req.body;

    if (!appointmentId) {
      return res.status(400).json({
        success: false,
        message: "Appointment ID is required",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Consultation completed",
      consultation: {
        appointmentId,
        diagnosis: diagnosis || "",
        prescription: prescription || "",
        notes: notes || "",
        status: "Completed",
      },
    });
  } catch (error) {
    console.error(
      "Complete Consultation Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to complete consultation",
    });
  }
};


module.exports = {
  doctorLogin,
  getDoctorProfile,
  getTodayPatients,
  getDoctorQueue,
  startConsultation,
  completeConsultation,
};