const express = require("express");
const { authenticateToken, authorizeRoles } = require("../../middleware/auth");

const {
  receptionLogin,
  getAppointments,
  updateAppointment,
  getPatients,
  searchPatient,
  registerWalkIn,
  checkInPatient,
} = require("../controllers/receptionController");

const router = express.Router();

// Reception login
router.post("/login", receptionLogin);

// Appointments
router.get("/appointments", authenticateToken, authorizeRoles("reception"), getAppointments);
router.put(
  "/appointments/:appointmentId",
  authenticateToken,
  authorizeRoles("reception"),
  updateAppointment
);

// Patients
router.get("/patients", authenticateToken, authorizeRoles("reception"), getPatients);
router.get("/patients/search", authenticateToken, authorizeRoles("reception"), searchPatient);

// Walk-in registration
router.post("/walk-in", authenticateToken, authorizeRoles("reception"), registerWalkIn);

// Patient check-in
router.post(
  "/appointments/:appointmentId/check-in",
  authenticateToken,
  authorizeRoles("reception"),
  checkInPatient
);

module.exports = router;