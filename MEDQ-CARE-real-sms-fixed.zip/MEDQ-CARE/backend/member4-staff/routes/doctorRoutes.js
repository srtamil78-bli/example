const express = require("express");
const { authenticateToken, authorizeRoles } = require("../../middleware/auth");

const {
  doctorLogin,
  getDoctorProfile,
  getTodayPatients,
  getDoctorQueue,
  startConsultation,
  completeConsultation,
} = require("../controllers/doctorController");

const router = express.Router();

// Doctor login
router.post("/login", doctorLogin);

// Doctor profile
router.get("/:doctorId/profile", authenticateToken, authorizeRoles("doctor"), getDoctorProfile);

// Today's patients
router.get("/:doctorId/patients/today", authenticateToken, authorizeRoles("doctor"), getTodayPatients);

// Doctor queue
router.get("/:doctorId/queue", authenticateToken, authorizeRoles("doctor"), getDoctorQueue);

// Start consultation
router.post("/consultation/start", authenticateToken, authorizeRoles("doctor"), startConsultation);

// Complete consultation
router.post("/consultation/complete", authenticateToken, authorizeRoles("doctor"), completeConsultation);

module.exports = router;