const express = require("express");
const { authenticateToken, authorizeRoles } = require("../../middleware/auth");

const {
  adminLogin,
  getHospitals,
  getDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment,
} = require("../controllers/adminController");

const router = express.Router();

// Admin login
router.post("/login", adminLogin);

// Hospitals
router.get("/hospitals", authenticateToken, authorizeRoles("admin"), getHospitals);

// Departments
router.get("/departments", authenticateToken, authorizeRoles("admin"), getDepartments);
router.post("/departments", authenticateToken, authorizeRoles("admin"), createDepartment);
router.put("/departments/:departmentId", authenticateToken, authorizeRoles("admin"), updateDepartment);
router.delete("/departments/:departmentId", authenticateToken, authorizeRoles("admin"), deleteDepartment);

module.exports = router;