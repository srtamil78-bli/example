// backend/member3-queue-engine/controllers/queueController.js

const queueEngine = require("../services/queueEngine");
const waitingTimeEngine = require("../services/waitingTimeEngine");

/**
 * ADD PATIENT TO QUEUE
 * POST /api/queue/check-in
 */
const checkInPatient = async (req, res) => {
  try {
    const {
      patientId,
      appointmentId,
      doctorId,
      departmentId,
      priority = "NORMAL",
    } = req.body;

    // Basic validation
    if (!patientId || !doctorId || !departmentId) {
      return res.status(400).json({
        success: false,
        message: "patientId, doctorId and departmentId are required",
      });
    }

    // Add patient to queue
    const queueEntry = await queueEngine.addPatient({
      patientId,
      appointmentId,
      doctorId,
      departmentId,
      priority,
    });

    // Calculate waiting time
    const waitingTime = await waitingTimeEngine.calculateWaitingTime(
      doctorId,
      departmentId,
      queueEntry.patientsAhead
    );

    return res.status(201).json({
      success: true,
      message: "Patient checked in successfully",
      data: {
        token: queueEntry.token,
        queueId: queueEntry.queueId,
        position: queueEntry.position,
        patientsAhead: queueEntry.patientsAhead,
        estimatedWait: waitingTime,
        status: queueEntry.status,
      },
    });
  } catch (error) {
    console.error("Check-in Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to check-in patient",
      error: error.message,
    });
  }
};

/**
 * GET COMPLETE QUEUE
 * GET /api/queue/:queueId
 */
const getQueue = async (req, res) => {
  try {
    const { queueId } = req.params;

    const queue = await queueEngine.getQueue(queueId);

    if (!queue) {
      return res.status(404).json({
        success: false,
        message: "Queue not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: queue,
    });
  } catch (error) {
    console.error("Get Queue Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to get queue",
      error: error.message,
    });
  }
};

/**
 * GET LIVE QUEUE STATUS
 * GET /api/queue/:queueId/status
 */
const getQueueStatus = async (req, res) => {
  try {
    const { queueId } = req.params;

    const status = await queueEngine.getQueueStatus(queueId);

    if (!status) {
      return res.status(404).json({
        success: false,
        message: "Queue not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: status,
    });
  } catch (error) {
    console.error("Queue Status Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to get queue status",
      error: error.message,
    });
  }
};

/**
 * CALL NEXT PATIENT
 * POST /api/queue/:queueId/call-next
 */
const callNext = async (req, res) => {
  try {
    const { queueId } = req.params;

    const currentPatient = await queueEngine.callNext(queueId);

    if (!currentPatient) {
      return res.status(404).json({
        success: false,
        message: "No patients waiting in the queue",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Next patient called successfully",
      data: currentPatient,
    });
  } catch (error) {
    console.error("Call Next Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to call next patient",
      error: error.message,
    });
  }
};

/**
 * SKIP PATIENT
 * POST /api/queue/:queueId/skip
 */
const skipPatient = async (req, res) => {
  try {
    const { queueId } = req.params;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Token is required",
      });
    }

    const result = await queueEngine.skipPatient(queueId, token);

    return res.status(200).json({
      success: true,
      message: "Patient skipped successfully",
      data: result,
    });
  } catch (error) {
    console.error("Skip Patient Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to skip patient",
      error: error.message,
    });
  }
};

/**
 * HOLD PATIENT
 * POST /api/queue/:queueId/hold
 */
const holdPatient = async (req, res) => {
  try {
    const { queueId } = req.params;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Token is required",
      });
    }

    const result = await queueEngine.holdPatient(queueId, token);

    return res.status(200).json({
      success: true,
      message: "Patient placed on hold",
      data: result,
    });
  } catch (error) {
    console.error("Hold Patient Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to hold patient",
      error: error.message,
    });
  }
};

/**
 * RESUME PATIENT
 * POST /api/queue/:queueId/resume
 */
const resumePatient = async (req, res) => {
  try {
    const { queueId } = req.params;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Token is required",
      });
    }

    const result = await queueEngine.resumePatient(queueId, token);

    return res.status(200).json({
      success: true,
      message: "Patient returned to queue",
      data: result,
    });
  } catch (error) {
    console.error("Resume Patient Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to resume patient",
      error: error.message,
    });
  }
};

/**
 * COMPLETE CURRENT PATIENT
 * POST /api/queue/:queueId/complete
 */
const completePatient = async (req, res) => {
  try {
    const { queueId } = req.params;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Token is required",
      });
    }

    const result = await queueEngine.completePatient(queueId, token);

    return res.status(200).json({
      success: true,
      message: "Patient consultation completed",
      data: result,
    });
  } catch (error) {
    console.error("Complete Patient Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to complete patient",
      error: error.message,
    });
  }
};

/**
 * GET PATIENTS AHEAD
 * GET /api/queue/:queueId/patients-ahead/:token
 */
const getPatientsAhead = async (req, res) => {
  try {
    const { queueId, token } = req.params;

    const patientsAhead = await queueEngine.getPatientsAhead(
      queueId,
      token
    );

    return res.status(200).json({
      success: true,
      data: {
        token,
        patientsAhead,
      },
    });
  } catch (error) {
    console.error("Patients Ahead Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to calculate patients ahead",
      error: error.message,
    });
  }
};

/**
 * GET WAITING TIME
 * GET /api/queue/:queueId/waiting-time/:token
 */
const getWaitingTime = async (req, res) => {
  try {
    const { queueId, token } = req.params;

    const patientsAhead = await queueEngine.getPatientsAhead(
      queueId,
      token
    );

    const waitingTime = await waitingTimeEngine.calculateWaitingTime(
      null,
      null,
      patientsAhead
    );

    return res.status(200).json({
      success: true,
      data: {
        token,
        patientsAhead,
        estimatedWait: waitingTime,
        unit: "minutes",
      },
    });
  } catch (error) {
    console.error("Waiting Time Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to calculate waiting time",
      error: error.message,
    });
  }
};

module.exports = {
  checkInPatient,
  getQueue,
  getQueueStatus,
  callNext,
  skipPatient,
  holdPatient,
  resumePatient,
  completePatient,
  getPatientsAhead,
  getWaitingTime,
};