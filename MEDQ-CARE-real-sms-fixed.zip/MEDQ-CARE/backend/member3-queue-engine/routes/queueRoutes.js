const express = require("express");

const router = express.Router();

const {
  checkInPatient,
  getQueue,
  getQueueStatus,
  callNext,
  skipPatient,
  holdPatient,
  resumePatient,
  completePatient,
  getPatientsAhead,
  getWaitingTime,
} = require("../controllers/queueController");

// Check-in patient
router.post("/check-in", checkInPatient);

// Get complete queue
router.get("/:queueId", getQueue);

// Get live queue status
router.get("/:queueId/status", getQueueStatus);

// Call next patient
router.post("/:queueId/call-next", callNext);

// Skip patient
router.post("/:queueId/skip", skipPatient);

// Hold patient
router.post("/:queueId/hold", holdPatient);

// Resume patient
router.post("/:queueId/resume", resumePatient);

// Complete patient
router.post("/:queueId/complete", completePatient);

// Get patients ahead
router.get(
  "/:queueId/patients-ahead/:token",
  getPatientsAhead
);

// Get waiting time
router.get(
  "/:queueId/waiting-time/:token",
  getWaitingTime
);

module.exports = router;