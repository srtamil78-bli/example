let tokenNumber = 0;

const generateToken = () => {
  tokenNumber++;

  const formattedNumber = String(tokenNumber).padStart(3, "0");

  return `A-${formattedNumber}`;
};

const resetToken = () => {
  tokenNumber = 0;
};

module.exports = {
  generateToken,
  resetToken,
};