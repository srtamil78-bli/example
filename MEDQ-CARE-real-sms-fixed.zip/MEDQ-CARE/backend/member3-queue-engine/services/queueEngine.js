const { generateToken } = require("../utils/tokenGenerator");

// Temporary in-memory queues
// Later this can be connected to your database.
const queues = {};

/**
 * Create a unique queue ID
 */
const createQueueId = (doctorId, departmentId) => {
  return `${doctorId}-${departmentId}`;
};

/**
 * ADD PATIENT TO QUEUE
 */
const addPatient = async ({
  patientId,
  appointmentId,
  doctorId,
  departmentId,
  priority = "NORMAL",
}) => {
  const queueId = createQueueId(doctorId, departmentId);

  // Create queue if it doesn't exist
  if (!queues[queueId]) {
    queues[queueId] = {
      queueId,
      doctorId,
      departmentId,
      currentPatient: null,
      patients: [],
    };
  }

  const token = generateToken();

  const queueEntry = {
    token,
    patientId,
    appointmentId: appointmentId || null,
    doctorId,
    departmentId,
    priority,
    status: "WAITING",
    joinedAt: new Date(),
  };

  queues[queueId].patients.push(queueEntry);

  // Sort priority patients first
  queues[queueId].patients.sort((a, b) => {
    if (a.priority === "HIGH" && b.priority !== "HIGH") {
      return -1;
    }

    if (a.priority !== "HIGH" && b.priority === "HIGH") {
      return 1;
    }

    return new Date(a.joinedAt) - new Date(b.joinedAt);
  });

  const position =
    queues[queueId].patients.findIndex(
      (patient) => patient.token === token
    ) + 1;

  const patientsAhead = position - 1;

  return {
    token,
    queueId,
    position,
    patientsAhead,
    status: "WAITING",
  };
};

/**
 * GET COMPLETE QUEUE
 */
const getQueue = async (queueId) => {
  const queue = queues[queueId];

  if (!queue) {
    return null;
  }

  return queue;
};

/**
 * GET LIVE QUEUE STATUS
 */
const getQueueStatus = async (queueId) => {
  const queue = queues[queueId];

  if (!queue) {
    return null;
  }

  const waiting = queue.patients.filter(
    (patient) => patient.status === "WAITING"
  );

  const serving = queue.patients.filter(
    (patient) => patient.status === "SERVING"
  );

  const completed = queue.patients.filter(
    (patient) => patient.status === "COMPLETED"
  );

  return {
    queueId,
    nowServing: queue.currentPatient
      ? queue.currentPatient.token
      : null,
    totalPatients: queue.patients.length,
    waiting: waiting.length,
    serving: serving.length,
    completed: completed.length,
    patients: queue.patients,
  };
};

/**
 * CALL NEXT PATIENT
 */
const callNext = async (queueId) => {
  const queue = queues[queueId];

  if (!queue) {
    return null;
  }

  // Complete currently serving patient before calling next
  if (queue.currentPatient) {
    queue.currentPatient.status = "COMPLETED";
  }

  const nextPatient = queue.patients.find(
    (patient) => patient.status === "WAITING"
  );

  if (!nextPatient) {
    queue.currentPatient = null;
    return null;
  }

  nextPatient.status = "SERVING";

  queue.currentPatient = nextPatient;

  return nextPatient;
};

/**
 * SKIP PATIENT
 */
const skipPatient = async (queueId, token) => {
  const queue = queues[queueId];

  if (!queue) {
    throw new Error("Queue not found");
  }

  const patient = queue.patients.find(
    (patient) => patient.token === token
  );

  if (!patient) {
    throw new Error("Patient token not found");
  }

  patient.status = "SKIPPED";

  if (
    queue.currentPatient &&
    queue.currentPatient.token === token
  ) {
    queue.currentPatient = null;
  }

  return patient;
};

/**
 * HOLD PATIENT
 */
const holdPatient = async (queueId, token) => {
  const queue = queues[queueId];

  if (!queue) {
    throw new Error("Queue not found");
  }

  const patient = queue.patients.find(
    (patient) => patient.token === token
  );

  if (!patient) {
    throw new Error("Patient token not found");
  }

  patient.status = "HOLD";

  if (
    queue.currentPatient &&
    queue.currentPatient.token === token
  ) {
    queue.currentPatient = null;
  }

  return patient;
};

/**
 * RESUME PATIENT
 */
const resumePatient = async (queueId, token) => {
  const queue = queues[queueId];

  if (!queue) {
    throw new Error("Queue not found");
  }

  const patient = queue.patients.find(
    (patient) => patient.token === token
  );

  if (!patient) {
    throw new Error("Patient token not found");
  }

  patient.status = "WAITING";

  return patient;
};

/**
 * COMPLETE PATIENT
 */
const completePatient = async (queueId, token) => {
  const queue = queues[queueId];

  if (!queue) {
    throw new Error("Queue not found");
  }

  const patient = queue.patients.find(
    (patient) => patient.token === token
  );

  if (!patient) {
    throw new Error("Patient token not found");
  }

  patient.status = "COMPLETED";

  if (
    queue.currentPatient &&
    queue.currentPatient.token === token
  ) {
    queue.currentPatient = null;
  }

  return patient;
};

/**
 * GET PATIENTS AHEAD
 */
const getPatientsAhead = async (queueId, token) => {
  const queue = queues[queueId];

  if (!queue) {
    throw new Error("Queue not found");
  }

  const patientIndex = queue.patients.findIndex(
    (patient) => patient.token === token
  );

  if (patientIndex === -1) {
    throw new Error("Patient token not found");
  }

  let patientsAhead = 0;

  for (let i = 0; i < patientIndex; i++) {
    if (queue.patients[i].status === "WAITING") {
      patientsAhead++;
    }
  }

  return patientsAhead;
};

module.exports = {
  addPatient,
  getQueue,
  getQueueStatus,
  callNext,
  skipPatient,
  holdPatient,
  resumePatient,
  completePatient,
  getPatientsAhead,
};