const AVERAGE_CONSULTATION_TIME = 10;

/**
 * Calculate estimated waiting time
 *
 * @param {string|null} doctorId
 * @param {string|null} departmentId
 * @param {number} patientsAhead
 * @returns {number} estimated waiting time in minutes
 */
const calculateWaitingTime = async (
  doctorId,
  departmentId,
  patientsAhead = 0
) => {
  if (patientsAhead <= 0) {
    return 0;
  }

  const waitingTime =
    patientsAhead * AVERAGE_CONSULTATION_TIME;

  return waitingTime;
};

module.exports = {
  calculateWaitingTime,
};