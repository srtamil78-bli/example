require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./member1-auth-patient/routes/authRoutes");
const patientRoutes = require("./member1-auth-patient/routes/patientRoutes");
const hospitalRoutes = require("./member2-hospital-appointment/routes/hospitalRoutes");
const { departmentRouter } = hospitalRoutes;
const appointmentRoutes = require("./member2-hospital-appointment/routes/appointmentRoutes");
const diagnosticRoutes = require("./member2-hospital-appointment/routes/diagnosticRoutes");
const queueRoutes = require("./member3-queue-engine/routes/queueRoutes");
const adminRoutes = require("./member4-staff/routes/adminRoutes");
const doctorRoutes = require("./member4-staff/routes/doctorRoutes");
const receptionRoutes = require("./member4-staff/routes/receptionRoutes");

const requiredEnv = [
  "JWT_SECRET",
  "ADMIN_USERNAME", "ADMIN_PASSWORD",
  "DOCTOR_ID", "DOCTOR_PASSWORD",
  "RECEPTION_USERNAME", "RECEPTION_PASSWORD",
];
const missingEnv = requiredEnv.filter((key) => !process.env[key]);
if (missingEnv.length) {
  throw new Error(`Missing required backend environment variables: ${missingEnv.join(", ")}`);
}

const app = express();
const allowedOrigin = process.env.FRONTEND_ORIGIN || "http://localhost:5173";

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: allowedOrigin, methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], credentials: false }));
app.use(express.json({ limit: "100kb" }));

const otpLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { success: false, message: "Too many OTP requests. Please try again later." },
});

app.get("/", (req, res) => {
  res.json({ success: true, message: "MEDQ-CARE Backend is running", api: "/api" });
});

app.get("/api/health", (req, res) => {
  res.json({ success: true, service: "medq-care-backend", timestamp: new Date().toISOString() });
});

app.use("/api/auth/login", otpLimiter);
app.use("/api/auth/register", otpLimiter);
app.use("/api/auth/resend-otp", otpLimiter);
app.use("/api/auth", authRoutes);
app.use("/api/patient", patientRoutes);

app.use("/api/hospitals", hospitalRoutes);
app.use("/api", departmentRouter);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/diagnostics", diagnosticRoutes);
app.use("/api/queue", queueRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/doctor", doctorRoutes);
app.use("/api/reception", receptionRoutes);

app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route not found", path: req.originalUrl });
});

app.use((err, req, res, next) => {
  console.error("Unhandled server error:", err);
  res.status(500).json({ success: false, message: "Internal server error" });
});

const PORT = Number(process.env.PORT || 5000);
app.listen(PORT, () => {
  console.log(`MEDQ-CARE server running on http://localhost:${PORT}`);
  console.log(`Allowed frontend origin: ${allowedOrigin}`);
  console.log("Real SMS OTP mode: Twilio Verify");
});
