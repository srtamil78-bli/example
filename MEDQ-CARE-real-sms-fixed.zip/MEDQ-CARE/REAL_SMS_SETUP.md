# MEDQ-CARE: real SMS OTP setup

This version uses Twilio Verify for real SMS OTP delivery. The backend never sends or stores the OTP itself. Twilio generates and delivers the verification code, and the backend checks the code with Twilio.

Official Twilio Verify documentation: https://www.twilio.com/docs/verify/api/verification

## 1. Configure the backend

Open `backend/.env` and fill these values from your Twilio Console/Verify Service:

```env
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_VERIFY_SERVICE_SID=your_verify_service_sid
```

Also keep a strong `JWT_SECRET` and set your frontend origin. Never put Twilio credentials in `frontend/.env` or React code.

## 2. Install and run

Backend:

```powershell
cd backend
npm install
npm start
```

Frontend (second terminal):

```powershell
cd frontend
npm install
npm run dev
```

## 3. Test

Open `http://localhost:5173/patient/login`, enter an Indian mobile number, and request an OTP. The SMS should be delivered to that phone by Twilio Verify. Enter the 6-digit code on the OTP screen.

## 4. Important

- Twilio requires phone numbers in E.164 format; the app converts Indian 10-digit numbers to `+91XXXXXXXXXX`.
- Twilio trial accounts can restrict recipients to verified numbers; account/compliance requirements may apply.
- The current project still uses in-memory sample data for many hospital/queue/staff features. For a production healthcare deployment, replace those controllers with the database layer, add HTTPS, audit controls, backups, and a proper secrets manager.

## If SMS does not arrive

Check the backend terminal. The application will print the Twilio Verify request status and any provider error, but it will **not print the OTP code**. Confirm the phone number is valid, the Twilio Verify Service SID is correct, and your Twilio account is allowed to send to the recipient. Trial accounts may restrict SMS to verified recipient numbers.
