const ROLES = {
  PATIENT: "PATIENT",
  HOSPITAL: "HOSPITAL",
  DOCTOR: "DOCTOR",
  STAFF: "STAFF",
  ADMIN: "ADMIN",
};

module.exports = ROLES;