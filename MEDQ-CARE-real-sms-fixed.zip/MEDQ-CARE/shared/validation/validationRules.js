const isRequired = (value) => {
  return value !== undefined && value !== null && value !== "";
};

const isValidPriority = (priority) => {
  return ["NORMAL", "HIGH", "EMERGENCY"].includes(priority);
};

module.exports = {
  isRequired,
  isValidPriority,
};