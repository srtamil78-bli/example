const API_RESPONSE = {
  SUCCESS: "success",
  DATA: "data",
  MESSAGE: "message",
};

module.exports = API_RESPONSE;