# MEDQ-CARE

Integrated React + Express healthcare management project.

## Run backend

Open Terminal 1:

```powershell
cd backend
npm install
npm start
```

Backend: http://localhost:5000

## Run frontend

Open Terminal 2:

```powershell
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite (normally http://localhost:5173).

## Main frontend routes

- `/` - MEDQ-CARE home
- `/patient/login` - Patient login
- `/patient/register` - Patient registration
- `/patient/otp` - Patient OTP
- `/patient/dashboard` - Patient dashboard
- `/hospitals` - Hospital module
- `/appointments` - Appointment module
- `/diagnostics/lab` - Laboratory
- `/diagnostics/imaging` - Imaging
- `/queue/live` - Live queue
- `/queue/control` - Queue control
- `/admin/login` - Admin login
- `/doctor/login` - Doctor login
- `/reception/login` - Reception login

## Demo staff credentials

- Admin: `admin` / `admin123`
- Doctor: `D021` / `demo123`
- Reception: `reception` / `reception123`

Patient OTP is printed in the backend terminal after requesting an OTP.

## Important

Do not commit real passwords, API keys, or database credentials. Keep secrets in `.env` and add `.env` to `.gitignore`.
